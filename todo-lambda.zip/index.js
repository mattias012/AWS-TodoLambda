// Importera en enkel modul för att generera unika ID:n
const { v4: uuidv4 } = require('uuid');

// Skapa en variabel för att spara todos
let todos = [];

// Detta är din Lambda-funktions huvudingångspunkt
exports.handler = async (event) => {
    const method = event.httpMethod;
    const body = event.body ? JSON.parse(event.body) : null;
    const id = event.pathParameters ? event.pathParameters.id : null;

    // Välj funktion baserat på HTTP-metoden
    switch (method) {
        case 'GET':
            return getTodos();
        case 'POST':
            return addTodo(body);
        case 'PUT':
            return updateTodo(id, body);
        case 'DELETE':
            return deleteTodo(id);
        default:
            return {
                statusCode: 405,
                body: JSON.stringify({ message: 'Method Not Allowed' }),
            };
    }
};
// Returnerar alla todos
function getTodos() {
    return {
        statusCode: 200,
        body: JSON.stringify(todos),
    };
}
// Lägg till en ny todo till listan
function addTodo(data) {
    if (!data || !data.text) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Invalid input' }),
        };
    }

    const newTodo = {
        id: uuidv4(), // Generera ett unikt ID för varje todo
        text: data.text,
        completed: false,
    };
    todos.push(newTodo);

    return {
        statusCode: 201,
        body: JSON.stringify(newTodo),
    };
}
// Uppdatera en existerande todo baserat på dess ID
function updateTodo(id, data) {
    if (!id || !data || !data.text) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Invalid input' }),
        };
    }

    const todo = todos.find((t) => t.id === id);
    if (!todo) {
        return {
            statusCode: 404,
            body: JSON.stringify({ message: 'Todo not found' }),
        };
    }

    // Uppdatera text och/eller status
    todo.text = data.text;
    if (data.completed !== undefined) {
        todo.completed = data.completed;
    }

    return {
        statusCode: 200,
        body: JSON.stringify(todo),
    };
}
// Ta bort en todo baserat på dess ID
function deleteTodo(id) {
    if (!id) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Invalid input' }),
        };
    }

    const index = todos.findIndex((t) => t.id === id);
    if (index === -1) {
        return {
            statusCode: 404,
            body: JSON.stringify({ message: 'Todo not found' }),
        };
    }

    todos.splice(index, 1);

    return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Todo deleted' }),
    };
}
